package com.speccore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeccoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpeccoreApplication.class, args);
    }
}
